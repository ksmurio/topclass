import { supabase } from '../config/supabase.js';
import bcrypt from 'bcryptjs';

// Create club
export const createClub = async (req, res) => {
  const { name, description, club_type, password, is_private } = req.body;
  const creator_id = req.user.id;

  if (!name || !club_type) {
    return res.status(400).json({ success: false, message: 'Name and club_type are required' });
  }

  try {
    let hashedPassword = null;
    if (is_private && password) {
      hashedPassword = await bcrypt.hash(password, 10);
    }

    const { data: club, error } = await supabase
      .from('clubs')
      .insert({
        name,
        description,
        club_type,
        creator_id,
        password: hashedPassword,
        is_private: is_private || false
      })
      .select()
      .single();

    if (error) throw error;

    // Add creator as member
    await supabase
      .from('user_clubs')
      .insert({ user_id: creator_id, club_id: club.id });

    res.status(201).json({ success: true, message: 'Club created', club });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Error creating club' });
  }
};

// Get all clubs
export const getClubs = async (req, res) => {
  try {
    const { data: clubs, error } = await supabase
      .from('clubs')
      .select('*, creator:user!creator_id(id, full_name, username)');

    if (error) throw error;

    res.status(200).json({ success: true, clubs });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Error fetching clubs' });
  }
};

// Join club
export const joinClub = async (req, res) => {
  const { club_id, password } = req.body;
  const user_id = req.user.id;

  try {
    // Get club
    const { data: club, error } = await supabase
      .from('clubs')
      .select('*')
      .eq('id', club_id)
      .single();

    if (error || !club) {
      return res.status(404).json({ success: false, message: 'Club not found' });
    }

    // Check if private
    if (club.is_private && club.password) {
      const validPassword = await bcrypt.compare(password || '', club.password);
      if (!validPassword) {
        return res.status(401).json({ success: false, message: 'Invalid password' });
      }
    }

    // Check if already member
    const { data: existing } = await supabase
      .from('user_clubs')
      .select('*')
      .eq('user_id', user_id)
      .eq('club_id', club_id)
      .single();

    if (existing) {
      return res.status(400).json({ success: false, message: 'Already a member' });
    }

    // Join
    await supabase
      .from('user_clubs')
      .insert({ user_id, club_id });

    res.status(200).json({ success: true, message: 'Joined club successfully' });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Error joining club' });
  }
};

// Get user clubs
export const getUserClubs = async (req, res) => {
  const user_id = req.user.id;

  try {
    const { data: userClubs, error } = await supabase
      .from('user_clubs')
      .select('club:clubs(*)')
      .eq('user_id', user_id);

    if (error) throw error;

    const clubs = userClubs.map(uc => uc.club);
    res.status(200).json({ success: true, clubs });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Error fetching user clubs' });
  }
};
