import express from 'express';
import { createClub, getClubs, joinClub, getUserClubs } from '../controllers/clubController.js';
import { authMiddleware } from '../middleware/authmiddleware.js';

const router = express.Router();

router.get('/', getClubs);
router.post('/create', authMiddleware, createClub);
router.post('/join', authMiddleware, joinClub);
router.get('/my-clubs', authMiddleware, getUserClubs);

export default router;
