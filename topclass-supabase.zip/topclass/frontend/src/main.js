import { createApp } from "vue";
import "./style.css";
import App from "./App.vue";
import { createVuetify } from "vuetify";
import * as components from "vuetify/components";
import * as directives from "vuetify/directives";
import "vuetify/styles";
import router from "./router";
import { animate } from 'animejs';


const vuetify = createVuetify({
  components,
  directives,
  theme: {
    defaultTheme: "light",
    themes: {
      light: {
        colors: {
          blue_darken: "#00268f",
        },
      },
    },
  },
  defaults: {
    VBtn: {
      color: "blue_darken",
      variant: "flat",
    },
  },
});

const app = createApp(App);

app.config.globalProperties.$animate = animate;
app.provide('animate', animate);

app.use(vuetify).use(router).mount("#app");