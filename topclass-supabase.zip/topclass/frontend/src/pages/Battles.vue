<template>
    Battles Page
</template>

<script>

</script>