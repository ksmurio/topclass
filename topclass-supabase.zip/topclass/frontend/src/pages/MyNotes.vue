<template>
    <v-container>
        <v-row>
            <v-col cols="12">
                <h1>My Notes</h1>
                <p>Create your goals</p>    
            </v-col>
        </v-row>
    </v-container>
</template>

<script>

</script>