<template>
    <v-footer>
        
    </v-footer>
</template>


<script>
</script>