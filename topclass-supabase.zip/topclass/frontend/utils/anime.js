import anime from 'animejs';



export default anime;
